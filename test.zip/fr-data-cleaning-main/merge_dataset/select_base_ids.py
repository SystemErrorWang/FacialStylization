import base64
import requests
import json
import numpy as np 
import pandas as pd
from tqdm import tqdm

import multiprocessing
import json
import os
import sys

host = '52.197.102.30'
base_port = 10051
debug = False

def get_quality(args):
    
    f, port, save_loc, force_save = args
    
    assert os.path.isfile(save_loc)
    info = pd.read_pickle(save_loc)
    
    return {
        'quality': info['quality']
    }

def get_vector(args):
    
    f, port, save_loc, force_save = args
    
    assert os.path.isfile(save_loc)
    info = pd.read_pickle(save_loc)
    
    return {
        'vector': info['vector']
    }

if __name__ == '__main__':
    
    force_save = False
    src = sys.argv[1]
    
    df = pd.read_csv(f'{src}.csv')
    print(df)
    print(df.shape)
    #df = df.iloc[:2000]

    # Create a multiprocessing pool with 4 processes
    
    # get quality
    data = []
    for i, (img, save_loc) in enumerate(zip(df.image_path.values, df.fr_info_path.values)):
        data += [(img, base_port+i%3, save_loc, force_save)]
        
    processes = 48*2
        
    all_quality = []
    with multiprocessing.Pool(processes=processes) as pool:
        # Apply the function to each element of the input list in parallel
        pbar = tqdm(total=len(df.image_path.values))
        
        for res in pool.imap(get_quality, data):
            pbar.update(1)
            all_quality += [res['quality']]
    
    df['quality'] = all_quality
    df['raw_index'] = df.index
    
    assert df['quality'].isnull().sum() == 0
    
    df = df.sort_values('quality', ascending=False).groupby('id').first().reset_index()
    print(df)
    print(df.shape, df.id.nunique())
    #df.to_csv('base_ids.csv', index=False)
    
    # get vectors
    data = []
    for i, (img, save_loc) in enumerate(zip(df.image_path.values, df.fr_info_path.values)):
        data += [(img, base_port+i%3, save_loc, force_save)]
    
    all_vector = []
    with multiprocessing.Pool(processes=processes) as pool:
        # Apply the function to each element of the input list in parallel
        pbar = tqdm(total=len(df.image_path.values))
        
        for res in pool.imap(get_vector, data):
            pbar.update(1)
            all_vector += [res['vector']]
    
    df['vector'] = all_vector
    df.to_csv(f'{src}_base_ids.csv', index=False)
    
    #all_vector = np.array(all_vector)
    #print(all_vector.shape)
    #pd.to_pickle(all_vector, 'base_vectors.pkl')
    