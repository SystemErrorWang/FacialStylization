import base64
import requests
import json
import numpy as np 
import pandas as pd
from tqdm import tqdm
import os; os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import sys

import multiprocessing
import json
import os
import torch

host = '52.197.102.30'
base_port = 10051
debug = False
threshold = 0.95
#threshold = 0.452 #0.9

def get_embedding(args):
    
    f, port = args
    
    url = f'http://{host}:{port}/api/v1/get_fr_info'
    f = f.replace('/home/MS-Celeb-1M/', '')
    
    with open(f, 'rb') as f:
        content = f.read()

    encoded_content = base64.b64encode(content).decode('utf-8')

    payload = json.dumps({
        "img": encoded_content,
        "autoRotate": False
    })

    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers = headers, data = payload)
    response = response.json()
    
    try:
        face_data = response['faces'][0]
        res = {
            'vector': json.dumps(face_data['vector']), # for similarity search, t-s learning
            'quality': face_data['details']['quality'], # to select register image for each id & filter valid stylegan photo
            'yaw': face_data['details']['angle']['yaw'], # to filter valid stylegan photo
            'pitch': face_data['details']['angle']['pitch'], # to filter valid stylegan photo
            'roll': face_data['details']['angle']['roll'], # to filter valid stylegan photo
            'occlusion': json.dumps(face_data['details']['occlusion']), # to filter valid stylegan photo
        }    
    except:
        res = {}
    
    return res

def convert_sim(np_sim):
    sourcePoints = [-1, 0.0, 0.3, 0.32, 0.354, 0.393, 0.429, 0.475, 1]
    destinationPoints = [0.0, 0.0, 0.1, 0.6, 0.7, 0.8, 0.85, 0.95, 1]

    np_sim[np_sim <= sourcePoints[0]] = destinationPoints[0]
    np_sim[np_sim >= sourcePoints[-1]] = destinationPoints[-1]
    filts = []
    for i in range(1, len(sourcePoints)):
        filt = (np_sim >= sourcePoints[i-1]) & (np_sim < sourcePoints[i])
        filts += [filt]
        
    for i, filt in enumerate(filts):
        i += 1
        np_sim[filt] = (np_sim[filt]-sourcePoints[i-1])/(sourcePoints[i]-sourcePoints[i-1])*(destinationPoints[i]-destinationPoints[i-1]) + destinationPoints[i-1]

    return np_sim

if __name__ == '__main__':
    
    force_save = False
    
    base_vectors = None
    merge_srcs = sys.argv[1:]
    
    batch_size = 1024
    cols = ['src', 'id', 'new_id', 'image_path', 'vector']
    all_vectors = None
    all_df = None
    all_full_df = None
    
    for i, src in enumerate(merge_srcs):
        file = f'{src}_base_ids.csv'
        assert os.path.isfile(file)
        
        df = pd.read_csv(file)
        df['src'] = src
        df['index'] = df.index
        df['new_id'] = df.src + '_' + df['index'].apply(lambda x: str(x)) 
        print(df.columns.tolist())
        assert 'id' in df.columns
        
        new_vectors = [json.loads(v) for v in tqdm(df.vector.values)]
        new_vectors = torch.tensor(new_vectors).cuda().float() # (20k, 256)
        
        df_full = pd.read_csv(f'{src}.csv')
        print(df_full.columns.tolist())
        
        if i == 0:
            all_vectors = new_vectors
            all_df = df[cols].copy()
            
            id_mapping = {id: new_id for id, new_id in zip(df.id.values, df.new_id.values)}
            df_full['new_id'] = df_full['id'].map(id_mapping)
        
            all_full_df = df_full
            print(all_df.shape[0])
            continue
            
        keep_index = []
        with torch.no_grad():
            steps = int(np.ceil(new_vectors.shape[0]/batch_size))
            pbar = tqdm(range(steps), total=steps)
            
            for step_ in pbar:
                s = step_ * batch_size
                e = min((1 + step_) * batch_size, new_vectors.shape[0])
                
                try:
                    sim = (all_vectors@new_vectors[s:e,:].T)
                except:
                    assert False
                
                sim, _ = sim.max(0)
                sim = sim.cpu().numpy()
                sim = convert_sim(sim)
                
                keep_index += list(np.array(np.arange(s, e))[sim < threshold])
                pbar.set_description(f"add {len(keep_index)} ids")
                
        all_vectors = torch.cat([all_vectors, new_vectors[keep_index,:]], 0)
        
        df = df.loc[keep_index, cols]        
        df_full = df_full.loc[df_full.id.isin(df.id.unique()),:]
        
        id_mapping = {id: new_id for id, new_id in zip(df.id.values, df.new_id.values)}
        df_full['new_id'] = df_full['id'].map(id_mapping)
        
        all_df = pd.concat([all_df, df], 0).reset_index(drop=True)
        all_full_df = pd.concat([all_full_df, df_full], 0).reset_index(drop=True)
        print(all_df.shape[0], all_full_df.shape[0])
        

    all_df.to_csv(f'{"-".join(merge_srcs)}_selected_ids.csv', index=False)
    all_full_df.to_csv(f'{"-".join(merge_srcs)}.csv', index=False)
    print('id num = ', all_df['new_id'].nunique())
    print(all_df.head(10))
    print(all_df.tail(10))
    
    print('image num = ', all_full_df.shape[0])
    print('id num = ', all_full_df['new_id'].nunique())
