1. Run python select_base_ids.py xxx
    - it will get base ids from xxx.csv 
    - output is xxx_base_ids.csv
2. Run python merge_base_ids.py xxx yyy zz
    - it will merge xxx.csv yyy.csv zzz.csv based on xxx_base_ids.csv, yyy_base_ids.csv, zzz_base_ids.csv
    - example: 
        - python merge_base_ids.py glint360k_level2 megaface_level2 laion5b_v1 laion5b_v2 laion5b_v3 ijbc_level2
        - python merge_base_ids.py ijbc_level2 glint360k_level2 megaface_level2 laion5b_v1 laion5b_v2 laion5b_v3 
        - python merge_base_ids.py ijbc_level2 ms-celeb-1m_level2 glint360k_level2 megaface_level2 laion5b_v1 laion5b_v2 laion5b_v3