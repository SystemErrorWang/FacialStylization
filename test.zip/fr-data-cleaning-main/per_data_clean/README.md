
1. Run data_summary.ipynb
    - change the folder name
    - check if the postfix (.jpg, .jpeg) is correct, otherwise the images cannot be found
2. Run embedding_extract.py
    - change the input file to the file from step 1.
3. Run select_base_ids.py
    - change the output file name (xxx_base_ids.csv)
3. Run deduplicate.py
    - use the output from step 2 (all.csv) and 3 (xxx_base_ids.csv)
    - change the `out` variable to the name meaningful
    - first, run level 1 deduplication with python deduplicate.py 1 # id deduplicate
    - second, run level 2 deduplication with python deduplicate.py 2 # within id aggregate