import base64
import requests
import json
import numpy as np 
import pandas as pd
from tqdm import tqdm

import multiprocessing
import json
import os

host = '216.153.61.153'
base_port = 10051
debug = False

def get_embedding(args):
    
    f, port, save_loc, force_save = args
    
    #file_path = '/home/MS-Celeb-1M/1k_ids/m.01_pwp/1-FaceId-0.jpg'
    #file_path = '/home/MS-Celeb-1M/1k_ids/m.01_pwp/34-FaceId-0.jpg'
    
    #port = 10053
    
    if not debug:
        if not force_save and os.path.isfile(save_loc):
            return pd.read_pickle(save_loc)
        
    url = f'http://{host}:{port}/api/v1/get_fr_info'
    #print(url)
    
    #f = f.replace('/home/MS-Celeb-1M/', '')
    
    #port = 10052
    #f = file_path
    
    with open(f, 'rb') as f:
        content = f.read()

    encoded_content = base64.b64encode(content).decode('utf-8')

    payload = json.dumps({
        "img": encoded_content,
        "autoRotate": False
    })

    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers = headers, data = payload)
    response = response.json()
    #print(port)
    #print(response['faces'][0]); 
    #print(list(response['faces'][0].keys()))
    #print(list(response['faces'][0]['details'].keys()))
    
    try:
        face_data = response['faces'][0]
        res = {
            'vector': json.dumps(face_data['vector']), # for similarity search, t-s learning
            'quality': face_data['details']['quality'], # to select register image for each id & filter valid stylegan photo
            'yaw': face_data['details']['angle']['yaw'], # to filter valid stylegan photo
            'pitch': face_data['details']['angle']['pitch'], # to filter valid stylegan photo
            'roll': face_data['details']['angle']['roll'], # to filter valid stylegan photo
            'position': json.dumps(face_data['details']['position']), # to do face crop
            'landmark': json.dumps(face_data['details']['landmarks']), # to do alignments
            'occlusion': json.dumps(face_data['details']['occlusion']), # to filter valid stylegan photo
        }
    except:
        res = {}
    
    #print(res)
    
    if not debug:
        pd.to_pickle(res, save_loc)
    
    return res

if __name__ == '__main__':
    
    force_save = False
    
    df = pd.read_csv('cropped_300.csv')
    #df = df.iloc[:2000]

    # Create a multiprocessing pool with 4 processes
    face_det = []
    
    data = []
    for i, (img, save_loc) in enumerate(zip(df.image_path.values, df.fr_info_path.values)):
        #if i <= 5807954:
        #    continue
            
        data += [(img, base_port+i%1, save_loc, force_save)]
        
    #print(data[0])
    #print(data[-1])
    #assert False
    
    processes = 24
    if debug:
        processes = 1
        
    all_data = []
    
    #for res in tqdm(data):
    #    get_embedding(res)
        
    with multiprocessing.Pool(processes=processes) as pool:
        # Apply the function to each element of the input list in parallel
        pbar = tqdm(total=len(data))
        
        for res in pool.imap(get_embedding, data):
            if debug:
                print(res)
                import sys; print(sys.getsizeof(res) / (1024 * 1024) * 20000000)
                assert False
            
            if len(res) == 0:
                face_det += [0]
            else:
                face_det += [1]
                
            #pd.to_pickle(vector, save_loc)
            pbar.update(1)
            all_data += [res]
    
    df['face_det'] = face_det
    print('fd ratio:', df.face_det.mean())
    
    # merge all meta information
    '''
    cols = ['quality', 'yaw', 'pitch', 'roll']
    df_ = pd.DataFrame(all_data)
    df_ = df_[cols]
    assert df.shape[0] == df_.shape[0]
    
    
    df = pd.concat([df.reset_index(drop=True), df_.reset_index(drop=True)], axis=1)
    df.to_csv('all.csv', index=False)
    
    df = df.loc[df['face_det']==1].reset_index(drop=True)
    df.to_csv('all_w_face.csv', index=False)
    '''
    
    df = df.loc[df['face_det']==1].reset_index(drop=True)
    df.to_csv('all.csv', index=False)
    
    print(df.head(), df.id.nunique(), df.shape)