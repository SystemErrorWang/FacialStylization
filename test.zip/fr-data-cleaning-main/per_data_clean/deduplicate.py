import base64
import requests
import json
import numpy as np 
import pandas as pd
from tqdm import tqdm
import os; os.environ['CUDA_VISIBLE_DEVICES'] = '4'
import sys

import multiprocessing
import json
import os
import torch

host = '52.197.102.30'
base_port = 10051
debug = False
threshold = 0.95
#threshold = 0.452 #0.9

def get_embedding(args):
    
    f, port = args
    
    url = f'http://{host}:{port}/api/v1/get_fr_info'
    f = f.replace('/home/MS-Celeb-1M/', '')
    
    with open(f, 'rb') as f:
        content = f.read()

    encoded_content = base64.b64encode(content).decode('utf-8')

    payload = json.dumps({
        "img": encoded_content,
        "autoRotate": False
    })

    headers = {
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers = headers, data = payload)
    response = response.json()
    
    try:
        face_data = response['faces'][0]
        res = {
            'vector': json.dumps(face_data['vector']), # for similarity search, t-s learning
            'quality': face_data['details']['quality'], # to select register image for each id & filter valid stylegan photo
            'yaw': face_data['details']['angle']['yaw'], # to filter valid stylegan photo
            'pitch': face_data['details']['angle']['pitch'], # to filter valid stylegan photo
            'roll': face_data['details']['angle']['roll'], # to filter valid stylegan photo
            'occlusion': json.dumps(face_data['details']['occlusion']), # to filter valid stylegan photo
        }    
    except:
        res = {}
    
    return res

def convert_sim(np_sim):
    sourcePoints = [-1, 0.0, 0.3, 0.32, 0.354, 0.393, 0.429, 0.475, 1]
    destinationPoints = [0.0, 0.0, 0.1, 0.6, 0.7, 0.8, 0.85, 0.95, 1]

    np_sim[np_sim <= sourcePoints[0]] = destinationPoints[0]
    np_sim[np_sim >= sourcePoints[-1]] = destinationPoints[-1]
    filts = []
    for i in range(1, len(sourcePoints)):
        filt = (np_sim >= sourcePoints[i-1]) & (np_sim < sourcePoints[i])
        filts += [filt]
        
    for i, filt in enumerate(filts):
        i += 1
        np_sim[filt] = (np_sim[filt]-sourcePoints[i-1])/(sourcePoints[i]-sourcePoints[i-1])*(destinationPoints[i]-destinationPoints[i-1]) + destinationPoints[i-1]

    return np_sim

def self_deduplicate(new_vectors, threshold):
    base_vectors = None
    keep_index = []
    with torch.no_grad():
        pbar = tqdm(range(new_vectors.shape[0]), total=new_vectors.shape[0])
        for i in pbar:
            if base_vectors is None:
                keep_index += [i]
                base_vectors =  new_vectors[[i],:]
                pbar.set_description(f"{len(keep_index)} new ids")
                continue

            try:
                sim = (base_vectors@new_vectors[[i],:].T)[:,0]
            except:
                print(i)
                print(new_vectors[[i],:])
                assert False
                
            sim = sim.cpu().numpy()
            sim = convert_sim(sim)
            
            if sim.max() > threshold:
                continue
            else:
                keep_index += [i]
                base_vectors = torch.cat([base_vectors, new_vectors[[i],:]], 0)
                pbar.set_description(f"{len(keep_index)} new ids")

    return base_vectors, keep_index

def level1_deduplicate(out, base_id_path):
    df = pd.read_csv(base_id_path)
    df = df.loc[df.id.apply(lambda x: x[0] != '.'),:].reset_index(drop=True)
    print(df)#; assert False
    
    new_vectors = [json.loads(v) for v in tqdm(df.vector.values)]
    new_vectors = torch.tensor(new_vectors).cuda().float() # (20k, 256)
    base_vectors, keep_index = self_deduplicate(new_vectors, threshold)
    
    print(new_vectors.shape[0], '->', len(keep_index))
    print(base_vectors.shape[0])

    df = df.loc[keep_index].reset_index(drop=True)
    df.to_csv(f'{out}_level1_selected_ids.csv', index=False)
    print(df.head(10))
    
    return df
    
def level2_deduplicate(out):
    df = pd.read_csv(f'{out}_level1.csv')
    print(df.head())
    
    keep_index = []
    sum_ = 0
    grouped = df.groupby('id')
    pbar = tqdm(grouped)
    for name, group in pbar:
        #print(name)
        #print(group)
        #print(group.shape)
        #assert False
        
        idx = group.index
        new_vectors = [json.loads(pd.read_pickle(v)['vector']) for v in group.fr_info_path.values]
        new_vectors = torch.tensor(new_vectors).cuda().float()
        
        sim_mat = new_vectors@new_vectors.T  # n-n binary matrix with sim
        rep = torch.argmax(sim_mat.sum(1)) # pick the one that has most similar pairs within the group
        
        sim = sim_mat[rep,:].cpu().numpy()
        sim = convert_sim(sim)
        
        keep = sim > threshold # keep only the one connected to the representive vecot
        keep_index_ = list(idx[keep])
        keep_index += keep_index_
        sum_ += len(idx)
        pbar.set_description(f"keep ratio: {len(keep_index)/sum_:.4f}")
        #print(sim_mat, sim_mat.sum(1), rep, keep, keep_index_, group.loc[keep_index_, 'image_path'])
        
        #assert False
        
    print(df.shape)
    df = df.loc[keep_index, :].reset_index(drop=True)
    df.to_csv(f'{out}_level2.csv', index=False)
    print(df.shape)
    
if __name__ == '__main__':
    
    force_save = False
    
    out = 'ijbc'
    base_id_path = 'ijbc_base_ids.csv'
    base_vectors = None
    level = int(sys.argv[1]) #ffhq256, ffhqu256, ffhq1024, celebahq
    
    # level 1: id deduplicate
    # level 2: within id aggregate
    
    
    if level == 1:
        df = level1_deduplicate(out, base_id_path)
        
        all_df = pd.read_csv('all.csv'); print(all_df.shape)
        all_df = all_df.loc[all_df.id.isin(df.id),:].reset_index(drop=True); print(all_df.shape)
        all_df.to_csv(f'{out}_level{level}.csv', index=False)

    elif level == 2:
        level2_deduplicate(out)
    else:
        assert False
    
    
    